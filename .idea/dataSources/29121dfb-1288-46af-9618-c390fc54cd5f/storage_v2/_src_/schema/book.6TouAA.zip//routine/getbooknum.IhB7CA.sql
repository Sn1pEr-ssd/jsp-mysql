create
    definer = root@localhost procedure getbooknum(IN name char(50))
begin
select book_number from books where book_name=name;
end;

