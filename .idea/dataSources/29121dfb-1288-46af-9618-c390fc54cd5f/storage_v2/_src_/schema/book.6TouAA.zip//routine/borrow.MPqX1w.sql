create
    definer = root@localhost procedure borrow(IN name char(50))
begin
update books set book_number = IF(book_number < 1, 0, book_number -1) where name = book_name;
end;

