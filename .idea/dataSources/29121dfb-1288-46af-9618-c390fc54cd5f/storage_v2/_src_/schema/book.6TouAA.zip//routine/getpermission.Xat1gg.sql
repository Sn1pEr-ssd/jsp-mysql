create
    definer = root@localhost procedure getpermission(IN name char(20))
begin
select permission from users where name=users.ID;
end;

